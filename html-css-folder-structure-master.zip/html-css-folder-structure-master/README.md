# html-css-folder-structure
Basic folder structure for HTML | CSS project
